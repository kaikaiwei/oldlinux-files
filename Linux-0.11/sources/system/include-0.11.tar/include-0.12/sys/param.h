#ifndef _SYS_PARAM_H
#define _SYS_PARAM_H

#define HZ 100

#endif
