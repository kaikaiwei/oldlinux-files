#define __LIBRARY__
#include <unistd.h>

_syscall1(time_t,time,time_t *,tptr)
