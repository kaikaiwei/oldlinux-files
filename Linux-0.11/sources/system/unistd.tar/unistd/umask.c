#define __LIBRARY__
#include <unistd.h>

_syscall1(mode_t,umask,mode_t,mask)
