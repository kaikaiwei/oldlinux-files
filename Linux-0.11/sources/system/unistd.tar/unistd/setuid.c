#define __LIBRARY__
#include <unistd.h>

_syscall1(int,setuid,uid_t,uid)
